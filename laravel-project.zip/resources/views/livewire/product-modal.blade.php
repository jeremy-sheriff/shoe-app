<div>
    <button
        wire:click="create"
        class="px-4 py-2 bg-blue-600 text-white text-sm font-semibold rounded-lg hover:bg-blue-700 transition"
    >
        + Add Product
    </button>

    @if ($showModal)

    @endif
</div>
