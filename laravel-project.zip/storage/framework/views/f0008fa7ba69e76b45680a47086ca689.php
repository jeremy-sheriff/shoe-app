<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => __('Dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Dashboard'))]); ?>
    <div class="flex h-full w-full flex-1 flex-col gap-4 rounded-xl">
        <div class="grid auto-rows-min gap-4 md:grid-cols-2">
            
            <div class="relative overflow-hidden rounded-xl border border-neutral-200 dark:border-neutral-700 shadow-sm bg-gray-50 dark:bg-zinc-800">
                <div class="p-6 space-y-6">
                    
                    <?php if(session('success')): ?>
                        <div class="mb-4 rounded-md bg-green-100 p-4 text-green-700">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    
                    <?php if($errors->any()): ?>
                        <div class="mb-4 rounded-md bg-red-100 p-4 text-red-700">
                            <strong>There were some problems with your input:</strong>
                            <ul class="mt-2 list-disc list-inside text-sm">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('orders.store')); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
                        <?php echo csrf_field(); ?>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="shoe_name" class="block text-sm font-medium text-gray-700 dark:text-white">Shoe Name</label>
                                <input type="text" name="shoe_name" id="shoe_name" required
                                       class="mt-1 block w-full rounded-md border border-gray-300 dark:border-zinc-600 bg-white dark:bg-zinc-900 px-3 py-2 shadow-sm focus:ring-indigo-500 dark:text-white">
                            </div>
                            <div>
                                <label for="size" class="block text-sm font-medium text-gray-700 dark:text-white">Size</label>
                                <input type="number" name="size" id="size" min="1" max="50" required
                                       class="mt-1 block w-full rounded-md border border-gray-300 dark:border-zinc-600 bg-white dark:bg-zinc-900 px-3 py-2 shadow-sm focus:ring-indigo-500 dark:text-white">
                            </div>
                            <div>
                                <label for="quantity" class="block text-sm font-medium text-gray-700 dark:text-white">Quantity</label>
                                <input type="number" name="quantity" id="quantity" min="1" required
                                       class="mt-1 block w-full rounded-md border border-gray-300 dark:border-zinc-600 bg-white dark:bg-zinc-900 px-3 py-2 shadow-sm focus:ring-indigo-500 dark:text-white">
                            </div>
                            <div>
                                <label for="color" class="block text-sm font-medium text-gray-700 dark:text-white">Color</label>
                                <input type="text" name="color" id="color" required
                                       class="mt-1 block w-full rounded-md border border-gray-300 dark:border-zinc-600 bg-white dark:bg-zinc-900 px-3 py-2 shadow-sm focus:ring-indigo-500 dark:text-white">
                            </div>
                        </div>

                        
                        <div>
                            <label for="description" class="block text-sm font-medium text-gray-700 dark:text-white">Description</label>
                            <textarea name="description" id="description" rows="3" placeholder="Optional notes about the shoe order..."
                                      class="mt-1 block w-full rounded-md border border-gray-300 dark:border-zinc-600 bg-white dark:bg-zinc-900 px-3 py-2 shadow-sm focus:ring-indigo-500 dark:text-white"></textarea>
                        </div>

                        
                        <div>
                            <label for="sample_image" class="block text-sm font-medium text-gray-700 dark:text-white">Upload Sample Image</label>
                            <input type="file" name="sample_image" id="sample_image" accept="image/*"
                                   class="">
                        </div>

                        
                        <div class="pt-2" style="background: black;">
                            <button type="submit"
                                    class="w-full inline-flex justify-center items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold rounded-md shadow-sm transition duration-150 ease-in-out">
                                Place Order Now
                            </button>
                        </div>


                    </form>
                </div>
            </div>

            
            <div class="relative overflow-hidden rounded-xl border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-zinc-800">
                <?php if (isset($component)) { $__componentOriginal1e4630c5daeca7ac226f30794c203a2d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1e4630c5daeca7ac226f30794c203a2d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.placeholder-pattern','data' => ['class' => 'absolute inset-0 size-full stroke-gray-900/20 dark:stroke-neutral-100/20']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('placeholder-pattern'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'absolute inset-0 size-full stroke-gray-900/20 dark:stroke-neutral-100/20']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1e4630c5daeca7ac226f30794c203a2d)): ?>
<?php $attributes = $__attributesOriginal1e4630c5daeca7ac226f30794c203a2d; ?>
<?php unset($__attributesOriginal1e4630c5daeca7ac226f30794c203a2d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1e4630c5daeca7ac226f30794c203a2d)): ?>
<?php $component = $__componentOriginal1e4630c5daeca7ac226f30794c203a2d; ?>
<?php unset($__componentOriginal1e4630c5daeca7ac226f30794c203a2d); ?>
<?php endif; ?>
            </div>
        </div>

        
        <div class="relative h-full flex-1 overflow-hidden rounded-xl border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-zinc-800">
            <div class="flex h-full w-full flex-1 flex-col gap-4 p-6">
                <div class="p-6 bg-white dark:bg-zinc-800 rounded-2xl shadow-md">


                    <div class="overflow-x-auto rounded-lg border border-zinc-200 dark:border-zinc-700">
                        <table class="min-w-full text-sm text-left">
                            <thead
                                class="bg-zinc-100 dark:bg-zinc-700 text-zinc-700 dark:text-zinc-100 uppercase text-xs tracking-wider">
                            <tr>
                                <th class="px-6 py-3">ID</th>
                                <th class="px-6 py-3">Description</th>
                                <th class="px-6 py-3">Status</th>
                                <th class="px-6 py-3">Order Date</th>
                                <th class="px-6 py-3">Order Sample</th>
                            </tr>
                            </thead>
                            <tbody class="text-zinc-800 dark:text-zinc-100 divide-y divide-zinc-200 dark:divide-zinc-700">
                            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-zinc-50 dark:hover:bg-zinc-700 transition">
                                    <td class="px-6 py-4"><?php echo e($loop->iteration); ?></td>
                                    <td class="px-6 py-4"><?php echo e($order->description); ?></td>
                                    <td class="px-6 py-4 capitalize">
                            <span class="inline-flex px-2 py-1 rounded text-xs font-medium
                                class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                    'bg-yellow-100 text-yellow-800' => $order->status === 'pending',
                                    'bg-blue-100 text-blue-800' => $order->status === 'processing',
                                    'bg-green-100 text-green-800' => $order->status === 'shipped',
                                    'bg-gray-200 text-gray-800' => $order->status === 'delivered',
                                ]); ?>"
                            ">
                                <?php echo e($order->status); ?>

                            </span>
                                    </td>
                                    <td class="px-6 py-4"><?php echo e($order->created_at->format('M d, Y')); ?></td>
                                    <td>
                                        <?php if($order->image_path): ?>
                                            <img height="40px" width="40px" src="<?php echo e(asset('storage/' . $order->image_path)); ?>" alt="Sample Image" class="w-20 h-20 object-cover rounded-md shadow">
                                        <?php endif; ?>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="px-6 py-4 text-center text-zinc-500 dark:text-zinc-400">
                                        No orders found.
                                    </td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-6">
                        <?php echo e($orders->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?><?php /**PATH /Users/jeremy/Herd/resources/views/livewire/orders/customer-orders.blade.php ENDPATH**/ ?>