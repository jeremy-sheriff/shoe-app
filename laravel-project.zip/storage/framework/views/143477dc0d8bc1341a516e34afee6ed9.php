<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => __('Dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Dashboard'))]); ?>
    <div class="flex flex-col gap-6 h-full w-full">
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            <div
                class="rounded-xl border border-neutral-200 dark:border-neutral-700 p-6 bg-white dark:bg-zinc-800 h-fit md:col-span-2">
                <form action="<?php echo e(route('products.store')); ?>" method="POST" enctype="multipart/form-data"
                      class="space-y-8">
                    <?php echo csrf_field(); ?>

                    <!-- Category and Shoe Name side by side -->
                    <div class="flex flex-col md:flex-row gap-4">
                        <!-- Category -->
                        <div class="w-full md:w-1/2 space-y-2">
                            <label for="category" class="block text-sm font-medium text-gray-800 dark:text-white">Category</label>
                            <select name="category" id="category" required
                                    class="mt-1 block w-full px-4 py-3 rounded-md border border-gray-300 dark:border-zinc-600 bg-white dark:bg-zinc-700 text-gray-900 dark:text-white">
                                <option value="">Select Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Shoe Name -->
                        <div class="w-full md:w-1/2 space-y-2">
                            <label for="name" class="block text-sm font-medium text-gray-700 dark:text-white">Shoe
                                Name</label>
                            <input value="<?php echo e($product->name); ?>" name="name" id="name" required
                                   class="mt-1 block w-full px-4 py-3 rounded-md border border-gray-300 dark:border-zinc-600 bg-white dark:bg-zinc-700 text-gray-900 dark:text-white">
                        </div>
                    </div>


                    <div class="flex flex-col md:flex-row gap-4">
                        <!-- Price -->
                        <div class="w-full md:w-1/2 space-y-2">
                            <label for="price" class="block text-sm font-medium text-gray-800 dark:text-white">Price
                                (Ksh)</label>
                            <input value="<?php echo e($product->price); ?>" type="number" name="price" id="price" step="50" min="100" required
                                   class="mt-1 block w-full px-4 py-3 rounded-md border border-gray-300 dark:border-zinc-600 bg-white dark:bg-zinc-700 text-gray-900 dark:text-white shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
                        </div>

                        <!-- Available colors -->
                        <div class="w-full md:w-1/2 space-y-2">
                            <?php $__currentLoopData = $product->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="flex items-center space-x-2 text-sm text-gray-700 dark:text-white">
                                    <input
                                        type="checkbox"
                                        name="colors[]"
                                        value="<?php echo e(strtolower($color)); ?>"
                                        class="h-4 w-4 text-primary border-gray-300 rounded focus:ring-primary"
                                        <?php echo e(in_array(strtolower($color), old('colors', $product->colors ?? [])) ? 'checked' : ''); ?>

                                    >
                                    <span><?php echo e($color); ?></span>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>

                    <!-- Description -->
                    <div class="w-full  space-y-2">
                        <label for="description" class="block text-sm font-medium text-gray-800 dark:text-white">Description</label>
                        <textarea name="description" id="description" rows="4" required
                                  class="mt-1 block w-full px-4 py-3 rounded-md border border-gray-300 dark:border-zinc-600 bg-white dark:bg-zinc-700 text-gray-900 dark:text-white shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
                            <?php echo e($product->description); ?>

                        </textarea>
                    </div>


                    <!-- Image Uploads -->
                    <div class="space-y-2">
                        <label class="block text-sm font-medium text-gray-700 dark:text-black mb-2">Upload
                            Images</label>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <!-- Image 1 -->
                            <div class="slim border-2 border-dashed rounded-lg p-4" data-label="Drop your image here"
                                 data-size="240,240" data-ratio="1:1">
                                <img src="<?php echo e(asset('storage/' . $product->images[0]->path)); ?>" alt="<?php echo e($product->name); ?>">
                                <input type="file" name="slim[]" required/>
                            </div>
                            <!-- Image 2 -->
                            <div class="slim border-2 border-dashed rounded-lg p-4" data-size="240,240"
                                 data-ratio="1:1">
                                <img src="<?php echo e(asset('storage/' . $product->images[1]->path)); ?>" alt="<?php echo e($product->name); ?>">
                                <input type="file" name="slim[]"/>
                            </div>
                            <!-- Image 3 -->
                            <div class="slim border-2 border-dashed rounded-lg p-4" data-size="240,240"
                                 data-ratio="1:1">
                                <img src="<?php echo e(asset('storage/' . $product->images[2]->path)); ?>" alt="<?php echo e($product->name); ?>">
                                <input type="file" name="slim[]"/>
                            </div>
                        </div>
                    </div>

                    <!-- Submit Button -->
                    <div class="mt-6">
                        <button type="submit"
                                class="w-full sm:w-auto px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-sm transition duration-200 ease-in-out">
                            Update Product
                        </button>
                    </div>
                </form>

            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?><?php /**PATH /Users/jeremy/Herd/resources/views/livewire/products/edit.blade.php ENDPATH**/ ?>