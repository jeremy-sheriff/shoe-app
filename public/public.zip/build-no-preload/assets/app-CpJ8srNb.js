new Slim(document.getElementById("myCropper"));
